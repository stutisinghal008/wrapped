package com.example.cs_2340_assignment2.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cs_2340_assignment2.R;
import com.example.cs_2340_assignment2.ui.SignupActivity;
import com.example.cs_2340_assignment2.data.spotify.auth.PkceUtil;
import com.example.cs_2340_assignment2.ui.MainActivity;

import java.security.NoSuchAlgorithmException;

public class LoginActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final EditText usernameEditText = findViewById(R.id.username);
        final EditText passwordEditText = findViewById(R.id.password);
        final Button loginButton = findViewById(R.id.login);
        final TextView signUpOption = findViewById(R.id.signup);

        loginButton.setOnClickListener(v -> {
            Log.d("LoginActivity", "Login button clicked");
            Log.d("LoginActivity", "Login successful");
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });


        signUpOption.setOnClickListener(v -> {
            Log.e("LoginActivity", "generating code challenge");
            Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
            startActivity(intent);
            finish();
        });
        // You need to override onActivityResult to handle the redirect from Spotify login
    }

}


package com.example.cs_2340_assignment2.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import com.example.cs_2340_assignment2.R;

public class ThirdFragment extends Fragment {

    OnMyButtonClickListener myButtonCallback;

    // Interface for callback to the activity
    public interface OnMyButtonClickListener {
        void onMyButtonClick();
    }

    OnMyButtonTwoClickListener myButtonTwoCallback;

    // Interface for callback to the activity
    public interface OnMyButtonTwoClickListener {
        void onMyButtonTwoClick();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            myButtonCallback = (OnMyButtonClickListener) context;
            myButtonTwoCallback = (OnMyButtonTwoClickListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnMyButtonClickListener and OnMyButtonTwoClickListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_third, container, false);

        // code for settings modal to pop up
        ImageButton openModalButton = view.findViewById(R.id.settings);
        openModalButton.setOnClickListener(v -> {
            DialogFragment dialog = new MyDialogFragment();
            dialog.show(getChildFragmentManager(), "MyDialogFragment");
        });

        // click listener for myButton to open YearlyOverviewFragment
        ImageButton myButton = view.findViewById(R.id.myButton);
        myButton.setOnClickListener(v -> myButtonCallback.onMyButtonClick());

        ImageButton myButton2 = view.findViewById(R.id.myButton2);
        myButton2.setOnClickListener(v -> myButtonTwoCallback.onMyButtonTwoClick());

        return view;
    }
}

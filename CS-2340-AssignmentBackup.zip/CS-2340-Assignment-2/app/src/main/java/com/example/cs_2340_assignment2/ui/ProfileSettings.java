package com.example.cs_2340_assignment2.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.cs_2340_assignment2.R;

public class ProfileSettings extends Fragment {

    private EditText editUsername;
    private EditText editName;
    private EditText editPassword;
    private Switch notifsToggle;
    private Switch publicProfToggle;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.profile_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize UI elements
        editUsername = view.findViewById(R.id.editUsername);
        editName = view.findViewById(R.id.editName);
        editPassword = view.findViewById(R.id.editPassword);
        notifsToggle = view.findViewById(R.id.notifs_toggle);
        publicProfToggle = view.findViewById(R.id.public_prof_toggle);

        // Save username button functionality
        ImageButton saveUsernameButton = view.findViewById(R.id.saveUsername);
        saveUsernameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editUsername.getText().toString();
                // Save username logic (e.g., update database or preferences)
                Log.d("ProfileSettingsFragment", "Username saved: " + username);
            }
        });

        // Save name button functionality
        ImageButton saveNameButton = view.findViewById(R.id.saveName);
        saveNameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editName.getText().toString();
                // Save name logic (e.g., update database or preferences)
                Log.d("ProfileSettingsFragment", "Name saved: " + name);
            }
        });

        // Save password button functionality
        ImageButton savePasswordButton = view.findViewById(R.id.savePassword);
        savePasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = editPassword.getText().toString();
                // Save password logic
                Log.d("ProfileSettingsFragment", "Password saved: " + password);
            }
        });

        // Toggle notification switch functionality
        notifsToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Toggle notification logic
            Log.d("ProfileSettingsFragment", "Notifications toggled: " + isChecked);
        });

        // Toggle public profile switch functionality
        publicProfToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Toggle public profile logic
            Log.d("ProfileSettingsFragment", "Public profile toggled: " + isChecked);
        });
    }
}

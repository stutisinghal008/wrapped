package com.example.cs_2340_assignment2.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.cs_2340_assignment2.data.spotify.Wrapped;
import com.example.cs_2340_assignment2.ui.MainActivity;
import com.example.cs_2340_assignment2.R;

import java.util.List;

public class YearlyOverviewFragment extends Fragment {
    private ProgressBar storyProgressBar;
    private Handler progressHandler = new Handler(Looper.getMainLooper());
    private int progressStatus = 0;

    private final Runnable progressRunnable = new Runnable() {
        @Override
        public void run() {
            if (progressStatus < 100) {
                progressStatus++;
                storyProgressBar.setProgress(progressStatus);
                progressHandler.postDelayed(this, 100); // Update every 100ms for smooth animation.
            } else {
                // Close the fragment once the progress completes.
                closeFragmentSmoothly();
            }
        }
    };

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.yearly_overview, container, false);
        storyProgressBar = view.findViewById(R.id.storyProgressBar);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // Hide bottom action bar.
        hideBottomActionBar();
        // Start the progress.
        progressHandler.post(progressRunnable);
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).setFragmentReady(true);
        }
    }

    private void closeFragmentSmoothly() {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).removeYearlyOverviewFragmentWithAnimation();
        }
    }

    private void hideBottomActionBar() {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).hideBottomActionBar();
        }
    }

    private void showBottomActionBar() {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).showBottomActionBar();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Show bottom action bar as the fragment is destroyed.
        showBottomActionBar();
        // Remove callbacks to avoid memory leaks.
        progressHandler.removeCallbacks(progressRunnable);
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).setFragmentReady(false);
        }
    }

    public void updateData(List<Wrapped.Artist> artists, List<Wrapped.Track> tracks, String mostCommonGenre) {
        if (getView() != null) {
            if (artists.size() >= 5) {
                ((TextView) getView().findViewById(R.id.textViewArtist1)).setText(artists.get(0).getName());
                ((TextView) getView().findViewById(R.id.textViewArtist2)).setText(artists.get(1).getName());
                ((TextView) getView().findViewById(R.id.textViewArtist3)).setText(artists.get(2).getName());
                ((TextView) getView().findViewById(R.id.textViewArtist4)).setText(artists.get(3).getName());
                ((TextView) getView().findViewById(R.id.textViewArtist5)).setText(artists.get(4).getName());
            }

            if (tracks.size() >= 5) {
                ((TextView) getView().findViewById(R.id.textViewSong1)).setText(tracks.get(0).getTitle());
                ((TextView) getView().findViewById(R.id.textViewSong2)).setText(tracks.get(1).getTitle());
                ((TextView) getView().findViewById(R.id.textViewSong3)).setText(tracks.get(2).getTitle());
                ((TextView) getView().findViewById(R.id.textViewSong4)).setText(tracks.get(3).getTitle());
                ((TextView) getView().findViewById(R.id.textViewSong5)).setText(tracks.get(4).getTitle());
            }
            ((TextView) getView().findViewById(R.id.textViewGenre)).setText(mostCommonGenre);
        }
    }
}

package com.example.cs_2340_assignment2.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.cs_2340_assignment2.R;
import com.example.cs_2340_assignment2.data.User;
import com.example.cs_2340_assignment2.data.UserScope;
import com.example.cs_2340_assignment2.data.spotify.auth.PkceUtil;
import com.example.cs_2340_assignment2.state.State;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

public class SignupActivity extends AppCompatActivity {

    private static final String CLIENT_ID = "3f6e08b6307b478398c6811e6d85a012";
    private static final String REDIRECT_URI = "myappspotifyauth://callback";
    private static final String SCOPES = "user-read-private playlist-read-private user-top-read";
    private static final int SPOTIFY_LOGIN_REQUEST = 1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        final EditText usernameInput = findViewById(R.id.usernameInput);
        final EditText passwordInput = findViewById(R.id.passwordInput);
        final Button signUpButton = findViewById(R.id.signUpButton);

        signUpButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString();
            String password = passwordInput.getText().toString();

            // Attempt to initiate Spotify login
            try {
                initiateSpotifyLogin(username, password);
            } catch (NoSuchAlgorithmException e) {
                Log.e("SignupActivity", "Error generating code challenge", e);
                // Show an error message to the user
            }
        });
    }

    private void initiateSpotifyLogin(String username, String password) throws NoSuchAlgorithmException {
        String codeVerifier = PkceUtil.generateCodeVerifier();
        String codeChallenge = PkceUtil.generateCodeChallenge(codeVerifier);

        String authUrl = "https://accounts.spotify.com/authorize" +
                "?client_id=" + CLIENT_ID +
                "&response_type=code" +
                "&redirect_uri=" + Uri.encode(REDIRECT_URI) +
                "&code_challenge_method=S256" +
                "&code_challenge=" + codeChallenge +
                "&scope=" + Uri.encode(SCOPES);

        SharedPreferences.Editor editor = getSharedPreferences("MyPrefs", MODE_PRIVATE).edit();
        editor.putString("code_verifier", codeVerifier);
        editor.apply();

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(authUrl));
        intent.putExtra("code_verifier", codeVerifier); // Pass the code verifier as an extra
        Log.d("SignupActivity", "Navigating to Spotify login");
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Handle the redirect with the authorization code
        // Create user and save to state here, after successful Spotify login
        if (resultCode == RESULT_OK && requestCode == SPOTIFY_LOGIN_REQUEST) {
            String username = data.getStringExtra("username");
            String password = data.getStringExtra("password");

            // Create user object after successful authentication
            User user = new User(
                    username, username, password,
                    new ArrayList<>(), new ArrayList<>(),
                    new ArrayList<>(), new ArrayList<>(), new ArrayList<>(),
                    UserScope.PRIVATE, null // Wrapped object to be populated later
            );

            State.getInstance().addUser(user);
            // Continue with application flow
        }
    }
}

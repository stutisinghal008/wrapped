package com.example.cs_2340_assignment2.data.spotify.auth;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import se.michaelthelin.spotify.SpotifyApi;

public class TokenExchangeUtil {
    private static final String CLIENT_ID = "3f6e08b6307b478398c6811e6d85a012";
    private static final String REDIRECT_URI = "myappspotifyauth://callback";
    private static final String TOKEN_URL = "https://accounts.spotify.com/api/token";
    private static final String CLIENT_SECRET = "085867c765a6474c8d8e3e2c55411d48";
    private static final SpotifyApi spotifyApi;


    static {
        try {
            spotifyApi = new SpotifyApi.Builder()
                    .setClientId(CLIENT_ID)
                    .setClientSecret(CLIENT_SECRET)
                    .setRedirectUri(new URI(REDIRECT_URI))
                    .build();
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }
//    private static final AuthorizationCodeRequest authorizationCodeRequest = spotifyApi.authorizationCode()
//            .build();

    public static String exchangeCodeForToken(String authorizationCode, String codeVerifier) {
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(TOKEN_URL).openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            String data = "client_id=" + CLIENT_ID +
                    "&grant_type=authorization_code" +
                    "&code=" + authorizationCode +
                    "&redirect_uri=" + REDIRECT_URI +
                    "&code_verifier=" + codeVerifier;

            try (OutputStream output = conn.getOutputStream()) {
                output.write(data.getBytes(StandardCharsets.UTF_8));
            }

            StringBuilder response = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
            }

            return response.toString(); // Handle JSON parsing with your preferred method
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Handle errors appropriately
        }

    }


    public static SpotifyApi getSpotifyApi() {
        return spotifyApi;
    }
}


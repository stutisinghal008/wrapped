package com.example.cs_2340_assignment2.ui;

import androidx.fragment.app.Fragment;

public class Archive extends Fragment {
}

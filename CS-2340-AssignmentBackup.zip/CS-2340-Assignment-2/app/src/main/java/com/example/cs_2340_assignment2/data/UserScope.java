package com.example.cs_2340_assignment2.data;

/**
 * Models user scopes and visibility settings in the app.
 */
public enum UserScope {
    PUBLIC,
    RESTRICTED,
    PRIVATE
}

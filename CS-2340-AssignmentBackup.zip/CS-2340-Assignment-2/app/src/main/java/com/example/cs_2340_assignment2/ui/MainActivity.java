package com.example.cs_2340_assignment2.ui;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.cs_2340_assignment2.R;
import com.example.cs_2340_assignment2.data.spotify.auth.TokenExchangeUtil;
import com.example.cs_2340_assignment2.data.spotify.Wrapped;
import com.example.cs_2340_assignment2.databinding.ActivityMainBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements ThirdFragment.OnMyButtonClickListener, ThirdFragment.OnMyButtonTwoClickListener {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    private String accessTokenFinal;
    private boolean isFragmentReady = false;
    public void setFragmentReady(boolean ready) {
        isFragmentReady = ready;
        if (isFragmentReady && accessTokenFinal != null) {
            updateYearlyOverviewFragment();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);
        getSupportActionBar().hide();

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);

        // Setting up BottomNavigationView with NavController
        BottomNavigationView navView = findViewById(R.id.bottom_navigation);
        NavigationUI.setupWithNavController(navView, navController);

        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        Log.d("MainActivity.java", "onCreate()");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    public void onMyButtonClick() {
        YearlyOverviewFragment yearlyOverviewFragment = new YearlyOverviewFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.setCustomAnimations(
                R.anim.story_fade_in, // enter
                R.anim.story_fade_out, // exit
                R.anim.story_fade_in, // popEnter
                R.anim.story_fade_out // popExit
        );
        transaction.add(R.id.container, yearlyOverviewFragment, "YearlyOverviewFragmentTag");
        transaction.addToBackStack(null);
        transaction.commit();

        Log.d("MainActivity.java", "onMyButtonClick()");
    }

    @Override
    public void onMyButtonTwoClick() {
        TopArtistsFragment1 topArtists1 = new TopArtistsFragment1();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.setCustomAnimations(
                R.anim.story_fade_in, // enter
                R.anim.story_fade_out, // exit
                R.anim.story_fade_in, // popEnter
                R.anim.story_fade_out // popExit
        );
        transaction.add(R.id.container, topArtists1, "TopArtistsFragmentTag");
        transaction.addToBackStack(null);
        transaction.commit();

        Log.d("MainActivity.java", "onMyButtonTwoClick()");
    }

    public void hideBottomActionBar() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setVisibility(View.GONE);
    }

    public void showBottomActionBar() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setVisibility(View.VISIBLE);
    }

    public void updateYearlyOverviewFragment() {
        if (!isFragmentReady || accessTokenFinal == null) {
            Log.d("MainActivity", "Fragment not ready or access token not available.");
            return;
        }

        Wrapped wrappedData = new Wrapped();
        try {
            wrappedData.convertPagingToArtist();
            wrappedData.convertPagingToTrack();
            Log.d("MainActivity", "Data fetched and converted.");
            String mostCommonGenre = wrappedData.findMostCommonGenre();

            YearlyOverviewFragment fragment = (YearlyOverviewFragment) getSupportFragmentManager().findFragmentByTag("YearlyOverviewFragmentTag");
            if (fragment != null) {
                fragment.updateData(wrappedData.getTopArtists(5), wrappedData.getTopTracks(5), mostCommonGenre);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "Failed to convert data", e);
        }
    }

    public void removeYearlyOverviewFragmentWithAnimation() {
        Fragment yearlyOverviewFragment = getSupportFragmentManager().findFragmentByTag("YearlyOverviewFragmentTag");
        if (yearlyOverviewFragment != null) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.setCustomAnimations(
                    R.anim.story_fade_in, // exit
                    R.anim.story_fade_out // popEnter
            );
            transaction.remove(yearlyOverviewFragment);
            transaction.commit();
        }

        Log.d("MainActivity.java", "removeYearlyOverviewFragmentWithAnimation()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Uri data = getIntent().getData();
        if (data != null && data.getScheme().equals("myappspotifyauth")) {
            String authorizationCode = data.getQueryParameter("code");
            SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
            String codeVerifier = prefs.getString("code_verifier", null);
            if (codeVerifier != null) {
                new TokenExchangeTask().execute(authorizationCode, codeVerifier);
            } else {
                Log.d("MainActivity.java", "Code verifier is null");
            }
        }

        Log.d("MainActivity.java", "onResume()");
    }

    public void loadNextFragment(Fragment currentFragment) {
        Fragment nextFragment = null;
        if (currentFragment instanceof TopArtistsFragment1) {
            nextFragment = new TopArtistsFragment2();
        } else if (currentFragment instanceof TopArtistsFragment2) {
            nextFragment = new TopArtistsFragment3();
        } else if (currentFragment instanceof TopArtistsFragment3) {
            nextFragment = new TopArtistsFragment4();
        } else if (currentFragment instanceof TopArtistsFragment4) {
            nextFragment = new TopArtistsFragment5();
        }

        if (nextFragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, nextFragment)
                    .commit();
        } else {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(R.anim.story_fade_in, R.anim.story_fade_out)
                    .remove(currentFragment)
                    .commit();
        }
    }

    private class TokenExchangeTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String authorizationCode = params[0];
            String codeVerifier = params[1];
            TokenExchangeUtil.getSpotifyApi().authorizationCode(authorizationCode);
            return TokenExchangeUtil.exchangeCodeForToken(authorizationCode, codeVerifier);
        }

        @Override
        protected void onPostExecute(String accessToken) {
            if (accessToken != null) {
                try {
                    Log.d("MainActivity", accessToken);
                    JSONObject json = new JSONObject(accessToken);
                    accessTokenFinal = json.getString("access_token");

                    Log.d("MainActivity.java", "Access Token Obtained");
                    TokenExchangeUtil.getSpotifyApi().setAccessToken(accessTokenFinal);

                    if (isFragmentReady) {
                        updateYearlyOverviewFragment();
                    }
                } catch (JSONException e) {
                    Log.e("MainActivity.java", "Error parsing JSON: " + e.getMessage());
                }
            } else {
                Log.d("MainActivity.java", "Access Token NOT Obtained");
            }
        }
    }
}
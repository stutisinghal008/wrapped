package com.example.cs_2340_assignment2.state;

import com.example.cs_2340_assignment2.data.Message;
import com.example.cs_2340_assignment2.data.MessageData;
import com.example.cs_2340_assignment2.data.User;
import com.example.cs_2340_assignment2.data.UserScope;
import com.example.cs_2340_assignment2.data.spotify.Wrapped;
import com.google.firebase.firestore.GeoPoint;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Factory class for creating objects from POJO and API values.
 */
public class Factory {

    /**
     * Create users from POJO values.
     *
     * @param o POJO object
     */
    public static User createUser(Object o) {
        if (!(o instanceof Map)) {
            throw new IllegalArgumentException("Object must be a Map! Invalid POJO!");
        } else {
            Map<String, Object> m = (Map<String, Object>) o;
            String id = (String) m.get("id");
            String username = (String) m.get("username");
            String password = (String) m.get("password");

            List<String> messages = (List<String>) m.get("messages");
            List<String> likes = (List<String>) m.get("likes");
            List<String> views = (List<String>) m.get("views");

            List<String> followers = (List<String>) m.get("followers");
            List<String> following = (List<String>) m.get("following");

            String s = (String) m.get("scope");
            UserScope scope = UserScope.valueOf(s);

            Wrapped w = createWrapped(m.get("spotifyData"));

            return new User(
                    id,
                    username,
                    password,
                    messages,
                    likes,
                    views,
                    followers,
                    following,
                    scope,
                    w);
        }
    }

    /**
     * Create messages from POJO values.
     *
     * @param o POJO object
     */
    public static Message createMessage(Object o) {
        if (!(o instanceof Map)) {
            throw new IllegalArgumentException("Object must be a Map! Invalid POJO!");
        } else {
            Map<String, Object> m = (Map<String, Object>) o;
            String id = (String) m.get("id");
            String root = (String) m.get("rootId");
            String parent = (String) m.get("parentId");
            String scope = (String) m.get("scope");
            Map<String, Object> content = (Map<String, Object>) m.get("content");

            List<String> authors = (List<String>) m.get("authors");
            List<String> likes = (List<String>) m.get("likes");
            List<String> views = (List<String>) m.get("views");
            List<String> replies = (List<String>) m.get("replies");

            Date date = (Date) m.get("date");
            boolean isDeleted = (boolean) m.get("isDeleted");

            MessageData data = new MessageData(
                    createWrapped(content.get("data")),
                    content.get("text").toString()
            );

            var message = new Message(
                    root,
                    parent,
                    id,
                    data,
                    authors,
                    likes,
                    views,
                    replies,
                    date,
                    isDeleted
            );
            message.setScope(UserScope.valueOf(scope));
            return message;
        }
    }

    /**
     * Create Wrapped objects from POJO values.
     *
     * @param o POJO object
     */
    public static Wrapped createWrapped(Object o) {
        if (!(o instanceof Map)) {
            throw new IllegalArgumentException("Object must be a Map! Invalid POJO!");
        } else {
            Map<String, Object> m = (Map<String, Object>) o;
            Wrapped wr = new Wrapped();
            var t = new ArrayList<Wrapped.Track>();
            var a = new ArrayList<Wrapped.Artist>();

            for (Object track : (List<Object>) m.get("tracks")) {
                Map<String, Object> tm = (Map<String, Object>) track;
                t.add(new Wrapped.Track(
                        tm.get("title").toString(),
                        (List<String>) tm.get("artists"),
                        tm.get("album_name").toString(),
                        Long.parseLong((String) tm.get("popularity")),
                        tm.get("uri").toString()
                ));
            }
            for (Object artist : (List<Object>) m.get("artists")) {
                Map<String, Object> am = (Map<String, Object>) artist;
                Collection<String> genres = new ArrayList<>();
                for (Object genre : (List<Object>) am.get("genres")) {
                    genres.add(genre.toString());
                }
                a.add(new Wrapped.Artist(
                        am.get("name").toString(),
                        genres,
                        am.get("uri").toString()
                ));
            }
            return wr;
        }
    }
}

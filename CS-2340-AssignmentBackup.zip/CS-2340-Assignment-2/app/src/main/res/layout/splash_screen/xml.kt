package layout.splash_screen

class xml {
}
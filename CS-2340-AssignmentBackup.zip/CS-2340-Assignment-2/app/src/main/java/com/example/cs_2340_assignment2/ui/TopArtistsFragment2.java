package com.example.cs_2340_assignment2.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.cs_2340_assignment2.R;

public class TopArtistsFragment2 extends Fragment {
    private ProgressBar storyProgressBar;
    private Handler progressHandler = new Handler(Looper.getMainLooper());
    private int progressStatus = 0;

    private final Runnable progressRunnable = new Runnable() {
        @Override
        public void run() {
            if (progressStatus < 100) {
                progressStatus++;
                storyProgressBar.setProgress(progressStatus);
                progressHandler.postDelayed(this, 100); // Update every 100ms for smooth animation.
            } else {
                // Close the fragment once the progress completes.
                closeFragmentSmoothly();
            }
        }
    };

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.topartist2, container, false);
        storyProgressBar = view.findViewById(R.id.storyProgressBar);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // Hide bottom action bar.
        hideBottomActionBar();
        // Start the progress.
        progressHandler.post(progressRunnable);
    }

    private void closeFragmentSmoothly() {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).loadNextFragment(this);
        }
    }

    private void hideBottomActionBar() {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).hideBottomActionBar();
        }
    }

    private void showBottomActionBar() {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).showBottomActionBar();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        progressHandler.post(progressRunnable);
    }

    @Override
    public void onPause() {
        super.onPause();
        progressHandler.removeCallbacks(progressRunnable);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Remove callbacks to avoid memory leaks.
        progressHandler.removeCallbacks(progressRunnable);
    }
}

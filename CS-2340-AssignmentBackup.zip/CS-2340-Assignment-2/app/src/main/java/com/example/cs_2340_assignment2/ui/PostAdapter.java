package com.example.cs_2340_assignment2.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cs_2340_assignment2.R;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.PostViewHolder> {

    private int itemCount;

    public PostAdapter(int itemCount) {
        this.itemCount = itemCount;
    }

    @Override
    public PostViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.post_fragment, parent, false);
        return new PostViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PostViewHolder holder, int position) {
        // No data binding is required as the layout is hardcoded
    }

    @Override
    public int getItemCount() {
        return itemCount;  // Return the number of items you want to show
    }

    public static class PostViewHolder extends RecyclerView.ViewHolder {
        public PostViewHolder(View itemView) {
            super(itemView);
            // No need to bind views unless there's interaction
        }
    }
}
